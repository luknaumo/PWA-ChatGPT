HM Kraków — natywny widget Android

Co pokazuje:
- odliczanie do półmaratonu 11.10.2026,
- dzisiejszy trening,
- najważniejsze parametry jednostki,
- trening na jutro,
- dotknięcie widgetu otwiera PWA:
  https://luknaumo.github.io/PWA-ChatGPT/

Ważne:
PWA zainstalowana z Chrome nie może sama dostarczyć natywnego widgetu Androida.
Dlatego ten dodatek jest małą natywną apką, która współpracuje z Twoją PWA.

Budowanie przez GitHub Actions:
1. Dodaj folder android-widget do głównego katalogu repozytorium PWA-ChatGPT.
2. Dodaj build-widget-apk.yml do .github/workflows/build-widget-apk.yml.
3. Po pushu wejdź: GitHub -> Actions -> Build HM Krakow Android widget APK.
4. Po zakończeniu pobierz artifact HM-Krakow-Widget-APK.
5. Rozpakuj pobrany ZIP i zainstaluj HM-Krakow-Widget.apk na telefonie.
6. Otwórz apkę i wybierz „Dodaj widget do ekranu głównego”
   albo: przytrzymaj ekran główny -> Widgety -> HM Kraków.

APK jest buildem debugowym, wystarczającym do prywatnej instalacji na Twoim telefonie.
