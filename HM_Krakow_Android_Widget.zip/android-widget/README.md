# Road to Berlin — widżet Androida

Widżet ekranu głównego pokazuje trening przypisany do dzisiejszej daty w telefonie.
Przyciski otwierają istniejącą PWA i odświeżają plan. Obsługiwany jest Android 8.0 lub nowszy.

Domyślny rozmiar to 3 kolumny i 2 rzędy. Widżet można zmieniać w obu kierunkach;
treść dopasowuje się do dostępnej szerokości i wysokości. W mniejszym rozmiarze
priorytetem są dzisiejszy trening i przycisk otwarcia aplikacji. Powiększenie
widżetu pozwala pokazać więcej informacji z planu.

Plan jest pobierany z https://luknaumo.github.io/PWA-ChatGPT/plan.json.
Walidacja poprzedza zapis; błędna odpowiedź nie zastępuje ostatniego poprawnego planu.
Instalator zawiera plan na 12–18.10.2026, który jest dostępny przed pierwszym połączeniem.
Odhaczenia treningów pozostają w lokalnej pamięci PWA.

Dodanie widżetu uruchamia pobranie planu. Android planuje kolejne pobrania co godzinę,
z uwzględnieniem dostępu do sieci i ograniczeń baterii. Przycisk „Odśwież” zleca
osobne pobranie. Zmiana daty, strefy czasowej i ponowne uruchomienie telefonu
aktualizują wybór dnia z zapisanej kopii. Alarm zmiany dnia jest nieprecyzyjny,
więc Android może go opóźnić. Usunięcie wszystkich widżetów wyłącza odświeżanie.

Projekt używa Java 17, Gradle 8.7, Android Gradle Plugin 8.6.1 i SDK 35.
Kompilacja i testy: `gradle testDebugUnitTest assembleDebug`.
GitHub Actions rozpakowuje projekt z `HM_Krakow_Android_Widget.zip`;
nazwa archiwum i identyfikator pakietu `pl.luknaumo.hmkrakow` są zachowane
dla zgodności z wcześniejszym projektem.

Po przejściu testów workflow zapisuje APK w `downloads/Road-to-Berlin-Widget-3x2.apk`
i jako artefakt Actions. Workflow jawnie ustawia WIDGET_KEYSTORE_PATH i signingConfigs.debug.storeFile.
Klucz debug jest tworzony i zapisywany w cache przed kompilacją,
aby kolejne instalatory mogły aktualizować ten sam dodatek. Utrata cache klucza
wymaga ponownej instalacji dodatku.

APK do osobistej instalacji jest podpisany kluczem debug. Aktualizacja istniejącego
dodatku wymaga zgodnego podpisu. Główna PWA jest osobną aplikacją. Starszy dodatek z instalatora
Road-to-Berlin-Widget.apk używa innego podpisu. Przed instalacją wersji 3×2
odinstaluj wyłącznie starszy dodatek widżetu; odhaczenia w PWA pozostają bez zmian.
Poprzedni instalator pozostaje dostępny i nie jest zastępowany.
