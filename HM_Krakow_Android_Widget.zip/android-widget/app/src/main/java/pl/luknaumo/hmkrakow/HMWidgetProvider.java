package pl.luknaumo.hmkrakow;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Renders saved data immediately. Network work belongs to the scheduled job. */
public final class HMWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_DAY_CHANGED =
            "pl.luknaumo.hmkrakow.action.DAY_CHANGED";
    public static final String ACTION_REFRESH =
            "pl.luknaumo.hmkrakow.action.REFRESH";
    private static final Locale POLISH = Locale.forLanguageTag("pl-PL");
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("EEE, d.MM", POLISH);
    private static final DateTimeFormatter TIME =
            DateTimeFormatter.ofPattern("HH:mm", POLISH);

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, HMWidgetProvider.class));
        if (ids.length == 0) return;
        PlanRepository.Snapshot snapshot = PlanRepository.load(context);
        for (int id : ids) render(context, manager, id, snapshot);
    }

    private static void render(Context context, AppWidgetManager manager, int widgetId,
            PlanRepository.Snapshot snapshot) {
        Bundle options = manager.getAppWidgetOptions(widgetId);
        int minWidth = positive(options, AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180);
        int minHeight = positive(options, AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110);
        int maxWidth = positive(options, AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, minWidth);
        int maxHeight = positive(options, AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, minHeight);
        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        // Launchers report portrait width and landscape height as the minimum bounds.
        RemoteViews portrait = buildViews(context, widgetId, snapshot, today, minWidth, maxHeight);
        RemoteViews landscape = buildViews(context, widgetId, snapshot, today, maxWidth, minHeight);
        manager.updateAppWidget(widgetId, new RemoteViews(landscape, portrait));
    }

    private static RemoteViews buildViews(Context context, int widgetId,
            PlanRepository.Snapshot snapshot, LocalDate today, int width, int height) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_hm);
        PlanData.Day day = snapshot.plan == null ? null : snapshot.plan.dayFor(today);
        String title;
        String meta;
        String details = "";
        views.setTextViewText(R.id.widget_brand, context.getString(R.string.app_name));
        views.setTextViewText(R.id.widget_date, today.format(DATE));
        if (day != null) {
            title = textOr(day.title, context.getString(R.string.widget_today));
            meta = textOr(day.meta, day.details);
            if (day.details != null && !day.details.equals(meta)) details = day.details;
        } else if (snapshot.plan != null) {
            title = context.getString(R.string.widget_no_day);
            meta = context.getString(R.string.widget_open_full_plan);
        } else {
            title = context.getString(R.string.widget_today);
            meta = context.getString(R.string.widget_connect);
        }
        views.setTextViewText(R.id.widget_title, title);
        views.setTextViewText(R.id.widget_meta, meta);
        views.setTextViewText(R.id.widget_details, details);
        views.setTextViewText(R.id.widget_status, status(context, snapshot));
        fitLayout(context, views, width, height, title, meta, details, today.format(DATE));
        views.setContentDescription(R.id.widget_root,
                today.format(DATE) + ". " + title + ". " + meta);
        Intent open = new Intent(context, OpenPlanActivity.class);
        open.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        PendingIntent openIntent = PendingIntent.getActivity(context, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_open, openIntent);
        views.setOnClickPendingIntent(R.id.widget_root, openIntent);
        Intent refresh = new Intent(context, HMWidgetProvider.class).setAction(ACTION_REFRESH);
        refresh.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        PendingIntent refreshIntent = PendingIntent.getBroadcast(context, widgetId, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshIntent);
        return views;
    }

    /** Reserve the action row first; fit optional text into the space above it. */
    private static void fitLayout(Context context, RemoteViews views, int widthDp, int heightDp,
            String title, String meta, String details, String date) {
        int padding = dp(context, widthDp < 220 || heightDp < 160 ? 8 : 12);
        int width = Math.max(1, dp(context, widthDp) - 2 * padding);
        int actionHeight = dp(context, heightDp < 150 ? 40 : 48);
        int fieldGap = dp(context, 3);
        int available = dp(context, heightDp) - 2 * padding - actionHeight - dp(context, 7);
        views.setViewPadding(R.id.widget_root, padding, padding, padding, padding);
        views.setInt(R.id.widget_open, "setHeight", actionHeight);
        views.setInt(R.id.widget_refresh, "setHeight", actionHeight);

        float titleSize = sp(context, 14f + Math.min(4f, Math.max(0f, (widthDp - 180f) / 50f)));
        float metaSize = sp(context, 12);
        float detailSize = sp(context, 12);
        float smallSize = sp(context, 10);
        float buttonSize = sp(context, 12);
        int buttonWidth = Math.max(1, width - dp(context, 54));
        TextPaint buttonPaint = paint(buttonSize, true);
        float buttonTextWidth = buttonPaint.measureText(context.getString(R.string.open_app));
        String buttonText = context.getString(R.string.open_app);
        int buttonLines = 1;
        if (buttonTextWidth > buttonWidth) {
            buttonText = context.getString(R.string.open_app_compact);
            buttonLines = 2;
            buttonTextWidth = 0;
            for (String line : buttonText.split("\n")) {
                buttonTextWidth = Math.max(buttonTextWidth, buttonPaint.measureText(line));
            }
        }
        if (buttonTextWidth > buttonWidth) buttonSize *= buttonWidth / buttonTextWidth;
        int buttonTextHeight = textHeight(buttonText, buttonSize, buttonWidth, buttonLines, true);
        if (buttonTextHeight > actionHeight) buttonSize *= actionHeight / (float) buttonTextHeight;
        views.setTextViewText(R.id.widget_open, buttonText);
        views.setInt(R.id.widget_open, "setMaxLines", buttonLines);
        size(views, R.id.widget_open, buttonSize);
        // A pictogram keeps its physical size when the user enlarges text.
        size(views, R.id.widget_refresh, dp(context, 22));
        size(views, R.id.widget_brand, smallSize);
        size(views, R.id.widget_date, smallSize);
        size(views, R.id.widget_meta, metaSize);
        size(views, R.id.widget_details, detailSize);
        size(views, R.id.widget_status, smallSize);

        int headerHeight = textHeight(date, smallSize, width, 1, false);
        boolean showHeader = available - headerHeight >= textHeight(title, titleSize, width, 1, true);
        views.setViewVisibility(R.id.widget_header, showHeader ? View.VISIBLE : View.GONE);
        if (showHeader) available -= headerHeight;
        float headerWidth = paint(smallSize, true).measureText(context.getString(R.string.app_name))
                + paint(smallSize, false).measureText(date) + dp(context, 6);
        views.setViewVisibility(R.id.widget_brand, headerWidth <= width ? View.VISIBLE : View.GONE);

        int oneTitleLine = textHeight(title, titleSize, width, 1, true);
        if (oneTitleLine > available && oneTitleLine > 0) {
            titleSize *= Math.max(1, available) / (float) oneTitleLine;
        }
        size(views, R.id.widget_title, titleSize);
        int titleLines = fittingLines(title, titleSize, width, available, 3, true);
        views.setInt(R.id.widget_title, "setMaxLines", Math.max(1, titleLines));
        available -= textHeight(title, titleSize, width, Math.max(1, titleLines), true);

        int metaLines = fittingLines(meta, metaSize, width, available - fieldGap, 2, false);
        views.setViewVisibility(R.id.widget_meta, metaLines > 0 ? View.VISIBLE : View.GONE);
        views.setInt(R.id.widget_meta, "setMaxLines", Math.max(1, metaLines));
        if (metaLines > 0) available -= textHeight(meta, metaSize, width, metaLines, false) + fieldGap;

        int statusHeight = textHeight("Odśw. 12:35", smallSize, width, 1, false) + fieldGap;
        boolean showStatus = available >= statusHeight;
        views.setViewVisibility(R.id.widget_status, showStatus ? View.VISIBLE : View.GONE);
        if (showStatus) available -= statusHeight;
        int detailLines = fittingLines(details, detailSize, width, available - fieldGap, 4, false);
        views.setViewVisibility(R.id.widget_details, detailLines > 0 ? View.VISIBLE : View.GONE);
        views.setInt(R.id.widget_details, "setMaxLines", Math.max(1, detailLines));
    }

    private static int fittingLines(String text, float size, int width, int height,
            int maximum, boolean bold) {
        if (text == null || text.trim().isEmpty() || height <= 0) return 0;
        for (int lines = maximum; lines > 0; lines--) {
            if (textHeight(text, size, width, lines, bold) <= height) return lines;
        }
        return 0;
    }

    private static int textHeight(String text, float size, int width, int lines, boolean bold) {
        return StaticLayout.Builder.obtain(text, 0, text.length(), paint(size, bold), width)
                .setIncludePad(false).setBreakStrategy(Layout.BREAK_STRATEGY_SIMPLE)
                .setMaxLines(lines).setEllipsize(TextUtils.TruncateAt.END)
                .setEllipsizedWidth(width).build().getHeight();
    }

    private static TextPaint paint(float size, boolean bold) {
        TextPaint paint = new TextPaint(TextPaint.ANTI_ALIAS_FLAG);
        paint.setTextSize(size);
        paint.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return paint;
    }

    private static void size(RemoteViews views, int id, float pixels) {
        views.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_PX, pixels);
    }

    private static int dp(Context context, float value) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value,
                context.getResources().getDisplayMetrics()));
    }

    private static float sp(Context context, float value) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, value,
                context.getResources().getDisplayMetrics());
    }

    private static int positive(Bundle options, String key, int fallback) {
        int value = options.getInt(key, fallback);
        return value > 0 ? value : fallback;
    }

    private static CharSequence status(Context context, PlanRepository.Snapshot snapshot) {
        if (snapshot.plan == null) return context.getString(R.string.widget_status_waiting);
        if (snapshot.lastFetchedAt == 0) return context.getString(R.string.widget_status_bundled);
        if (snapshot.lastRequestFailed) return context.getString(R.string.widget_status_saved);
        String time = Instant.ofEpochMilli(snapshot.lastFetchedAt)
                .atZone(ZoneId.systemDefault()).format(TIME);
        return context.getString(R.string.widget_status_updated, time);
    }

    private static String textOr(String value, String fallback) {
        return value != null && !value.trim().isEmpty() ? value : fallback == null ? "" : fallback;
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        PlanRepository.Snapshot snapshot = PlanRepository.load(context);
        for (int id : ids) render(context, manager, id, snapshot);
        WidgetScheduler.ensure(context);
        WidgetScheduler.requestRefresh(context);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        updateAll(context);
        WidgetScheduler.ensure(context);
        WidgetScheduler.requestRefresh(context);
    }

    @Override
    public void onDisabled(Context context) {
        WidgetScheduler.cancel(context);
        super.onDisabled(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
            int widgetId, Bundle newOptions) {
        render(context, manager, widgetId, PlanRepository.load(context));
        WidgetScheduler.ensure(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        boolean refresh = ACTION_REFRESH.equals(action);
        boolean dayChanged = ACTION_DAY_CHANGED.equals(action);
        boolean systemChange = Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action);
        if (refresh || dayChanged || systemChange) {
            updateAll(context);
            WidgetScheduler.ensure(context);
            if (dayChanged || systemChange) WidgetScheduler.scheduleMidnight(context);
            WidgetScheduler.requestRefresh(context);
            return;
        }
        super.onReceive(context, intent);
    }
}
