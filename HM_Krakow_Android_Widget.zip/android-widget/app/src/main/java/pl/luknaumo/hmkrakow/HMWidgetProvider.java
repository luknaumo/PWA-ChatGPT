package pl.luknaumo.hmkrakow;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;
import java.time.LocalDate;

public class HMWidgetProvider extends AppWidgetProvider {
    static void updateAppWidget(Context context, AppWidgetManager manager, int appWidgetId) {
        LocalDate today = LocalDate.now();
        PlanData.Day day = PlanData.forDate(today);
        Bundle opts = manager.getAppWidgetOptions(appWidgetId);
        int minWidth = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 220);
        boolean compact = minWidth < 230;

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_hm);
        views.setTextViewText(R.id.widget_count, PlanData.countdown(today));
        views.setTextViewText(R.id.widget_caption, PlanData.countdownCaption(today));
        views.setTextViewText(R.id.widget_label, day.label);
        views.setTextViewText(R.id.widget_title, day.title);
        views.setTextViewText(R.id.widget_details, day.details);
        views.setTextViewText(R.id.widget_next, PlanData.nextLine(today));
        views.setViewVisibility(R.id.widget_next, compact ? View.GONE : View.VISIBLE);

        int bg = R.drawable.widget_background;
        if (today.equals(PlanData.RACE_DATE)) bg = R.drawable.widget_background_race;
        else if (day.label.equals("REST") || day.label.equals("TAPER")) bg = R.drawable.widget_background_rest;
        else if (day.label.equals("KLUCZOWY")) bg = R.drawable.widget_background_key;
        views.setInt(R.id.widget_root, "setBackgroundResource", bg);

        Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(PlanData.PWA_URL));
        PendingIntent pi = PendingIntent.getActivity(context, 100, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pi);
        manager.updateAppWidget(appWidgetId, views);
    }

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateAppWidget(context, manager, id);
    }

    @Override public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int appWidgetId, Bundle newOptions) {
        updateAppWidget(context, manager, appWidgetId);
    }
}
