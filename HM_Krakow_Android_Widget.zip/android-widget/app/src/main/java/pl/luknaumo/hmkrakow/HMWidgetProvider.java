package pl.luknaumo.hmkrakow;
import android.app.PendingIntent;import android.appwidget.*;import android.content.*;import android.net.Uri;import android.widget.RemoteViews;
public class HMWidgetProvider extends AppWidgetProvider {
 static void update(Context c,AppWidgetManager m,int id){
  PlanData.Day d=PlanData.today(); RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_hm);
  v.setTextViewText(R.id.widget_countdown,PlanData.countdown()); v.setTextViewText(R.id.widget_title,d.title); v.setTextViewText(R.id.widget_details,d.details); v.setTextViewText(R.id.widget_next,"Jutro: "+PlanData.tomorrow().title);
  Intent open=new Intent(Intent.ACTION_VIEW, Uri.parse(PlanData.PWA_URL)); PendingIntent pi=PendingIntent.getActivity(c,100,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); v.setOnClickPendingIntent(R.id.widget_root,pi); m.updateAppWidget(id,v);
 }
 static void updateAll(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);ComponentName n=new ComponentName(c,HMWidgetProvider.class);for(int id:m.getAppWidgetIds(n))update(c,m,id);}
 @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);} 
 @Override public void onEnabled(Context c){super.onEnabled(c);updateAll(c);} 
 @Override public void onReceive(Context c,Intent i){super.onReceive(c,i); if(AppWidgetManager.ACTION_APPWIDGET_UPDATE.equals(i.getAction())) updateAll(c);} 
}
