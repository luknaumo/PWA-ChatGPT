package pl.luknaumo.hmkrakow;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;

import java.time.LocalDate;

public class HMWidgetProvider extends AppWidgetProvider {

    static void updateAppWidget(Context context, AppWidgetManager manager, int appWidgetId) {
        LocalDate today = LocalDate.now();
        PlanData.Day day = PlanData.forDate(today);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_hm);
        views.setTextViewText(R.id.widget_countdown, PlanData.countdown(today));
        views.setTextViewText(R.id.widget_title, day.title);
        views.setTextViewText(R.id.widget_details, day.details);
        views.setTextViewText(R.id.widget_next, PlanData.nextLine(today));

        Intent open = new Intent(Intent.ACTION_VIEW, Uri.parse(PlanData.PWA_URL));
        PendingIntent pi = PendingIntent.getActivity(
                context, 100, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        views.setOnClickPendingIntent(R.id.widget_root, pi);

        manager.updateAppWidget(appWidgetId, views);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateAppWidget(context, manager, id);
    }
}
