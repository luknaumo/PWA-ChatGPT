package pl.luknaumo.hmkrakow;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Renders saved data immediately. Network work belongs to the scheduled job. */
public final class HMWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_DAY_CHANGED =
            "pl.luknaumo.hmkrakow.action.DAY_CHANGED";
    public static final String ACTION_REFRESH =
            "pl.luknaumo.hmkrakow.action.REFRESH";
    private static final Locale POLISH = Locale.forLanguageTag("pl-PL");
    private static final DateTimeFormatter DATE =
            DateTimeFormatter.ofPattern("EEE, d.MM", POLISH);
    private static final DateTimeFormatter TIME =
            DateTimeFormatter.ofPattern("HH:mm", POLISH);

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, HMWidgetProvider.class));
        if (ids.length == 0) return;
        PlanRepository.Snapshot snapshot = PlanRepository.load(context);
        for (int id : ids) render(context, manager, id, snapshot);
    }

    private static void render(Context context, AppWidgetManager manager, int widgetId,
            PlanRepository.Snapshot snapshot) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_hm);
        LocalDate today = LocalDate.now(ZoneId.systemDefault());
        PlanData.Day day = snapshot.plan == null ? null : snapshot.plan.dayFor(today);
        Bundle options = manager.getAppWidgetOptions(widgetId);
        int height = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 160);
        boolean spacious = height >= 220;
        views.setTextViewText(R.id.widget_brand, context.getString(R.string.app_name));
        views.setTextViewText(R.id.widget_date, today.format(DATE));
        views.setInt(R.id.widget_title, "setMaxLines", spacious ? 2 : 1);
        views.setInt(R.id.widget_meta, "setMaxLines", height >= 185 ? 2 : 1);
        views.setViewVisibility(R.id.widget_details, View.GONE);
        if (day != null) {
            views.setTextViewText(R.id.widget_title, textOr(day.title,
                    context.getString(R.string.widget_today)));
            views.setTextViewText(R.id.widget_meta, textOr(day.meta, day.details));
            if (height >= 270 && day.details != null && !day.details.trim().isEmpty()
                    && !day.details.equals(day.meta)) {
                views.setTextViewText(R.id.widget_details, day.details);
                views.setViewVisibility(R.id.widget_details, View.VISIBLE);
            }
        } else if (snapshot.plan != null) {
            views.setTextViewText(R.id.widget_title, context.getString(R.string.widget_no_day));
            views.setTextViewText(R.id.widget_meta,
                    context.getString(R.string.widget_open_full_plan));
        } else {
            views.setTextViewText(R.id.widget_title, context.getString(R.string.widget_today));
            views.setTextViewText(R.id.widget_meta, context.getString(R.string.widget_connect));
        }
        views.setTextViewText(R.id.widget_status, status(context, snapshot));
        Intent open = new Intent(context, OpenPlanActivity.class);
        open.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        PendingIntent openIntent = PendingIntent.getActivity(context, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_open, openIntent);
        views.setOnClickPendingIntent(R.id.widget_root, openIntent);
        Intent refresh = new Intent(context, HMWidgetProvider.class).setAction(ACTION_REFRESH);
        refresh.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        PendingIntent refreshIntent = PendingIntent.getBroadcast(context, widgetId, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshIntent);
        manager.updateAppWidget(widgetId, views);
    }

    private static CharSequence status(Context context, PlanRepository.Snapshot snapshot) {
        if (snapshot.plan == null) return context.getString(R.string.widget_status_waiting);
        if (snapshot.lastFetchedAt == 0) return context.getString(R.string.widget_status_bundled);
        if (snapshot.lastRequestFailed) return context.getString(R.string.widget_status_saved);
        String time = Instant.ofEpochMilli(snapshot.lastFetchedAt)
                .atZone(ZoneId.systemDefault()).format(TIME);
        return context.getString(R.string.widget_status_updated, time);
    }

    private static String textOr(String value, String fallback) {
        return value != null && !value.trim().isEmpty() ? value : fallback == null ? "" : fallback;
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        PlanRepository.Snapshot snapshot = PlanRepository.load(context);
        for (int id : ids) render(context, manager, id, snapshot);
        WidgetScheduler.ensure(context);
        WidgetScheduler.requestRefresh(context);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        updateAll(context);
        WidgetScheduler.ensure(context);
        WidgetScheduler.requestRefresh(context);
    }

    @Override
    public void onDisabled(Context context) {
        WidgetScheduler.cancel(context);
        super.onDisabled(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
            int widgetId, Bundle newOptions) {
        render(context, manager, widgetId, PlanRepository.load(context));
        WidgetScheduler.ensure(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        boolean refresh = ACTION_REFRESH.equals(action);
        boolean dayChanged = ACTION_DAY_CHANGED.equals(action);
        boolean systemChange = Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action);
        if (refresh || dayChanged || systemChange) {
            updateAll(context);
            WidgetScheduler.ensure(context);
            if (dayChanged || systemChange) WidgetScheduler.scheduleMidnight(context);
            WidgetScheduler.requestRefresh(context);
            return;
        }
        super.onReceive(context, intent);
    }
}
