package pl.luknaumo.hmkrakow;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(36), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(11,16,32));

        TextView title = new TextView(this);
        title.setText("HM Kraków");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.START);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView body = new TextView(this);
        body.setText("\nWidget pokazuje dzisiejszy trening, kolejny dzień i odliczanie do półmaratonu. Dotknięcie widgetu otwiera Twoją PWA.");
        body.setTextColor(Color.rgb(190,200,220));
        body.setTextSize(16);
        root.addView(body);

        Button add = new Button(this);
        add.setText("Dodaj widget do ekranu głównego");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = dp(24);
        root.addView(add, bp);

        add.setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                AppWidgetManager mgr = getSystemService(AppWidgetManager.class);
                ComponentName provider = new ComponentName(this, HMWidgetProvider.class);
                if (mgr.isRequestPinAppWidgetSupported()) {
                    mgr.requestPinAppWidget(provider, null, null);
                }
            }
        });

        Button open = new Button(this);
        open.setText("Otwórz pełny plan");
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        op.topMargin = dp(10);
        root.addView(open, op);
        open.setOnClickListener(v -> startActivity(
                new Intent(Intent.ACTION_VIEW, Uri.parse(PlanData.PWA_URL))
        ));

        setContentView(root);
    }
}
