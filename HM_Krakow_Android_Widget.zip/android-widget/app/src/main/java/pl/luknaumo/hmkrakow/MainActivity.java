package pl.luknaumo.hmkrakow;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    int dp(float x) {
        return (int) (x * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        HMWidgetProvider.updateAll(this);

        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(24), dp(36), dp(24), dp(24));
        r.setBackgroundColor(Color.rgb(11, 16, 32));

        TextView t = new TextView(this);
        t.setText("HM Kraków Widget");
        t.setTextColor(Color.WHITE);
        t.setTextSize(27);
        r.addView(t);

        TextView x = new TextView(this);
        x.setText("1. Dodaj widżet.\n2. Gdy działa, możesz ukryć tę ikonę — widżet pozostanie aktywny.");
        x.setTextColor(Color.rgb(190, 200, 220));
        x.setTextSize(16);
        r.addView(x);

        Button add = new Button(this);
        add.setText("Dodaj widżet");
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        p.topMargin = dp(20);
        r.addView(add, p);

        add.setOnClickListener(v -> {
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                AppWidgetManager m = getSystemService(AppWidgetManager.class);
                ComponentName n = new ComponentName(this, HMWidgetProvider.class);
                if (m.isRequestPinAppWidgetSupported()) {
                    m.requestPinAppWidget(n, null, null);
                }
            }
        });

        Button hide = new Button(this);
        hide.setText("Ukryj ikonę helpera");
        LinearLayout.LayoutParams q = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        q.topMargin = dp(10);
        r.addView(hide, q);

        hide.setOnClickListener(v -> {
            getPackageManager().setComponentEnabledSetting(
                    new ComponentName(this, "pl.luknaumo.hmkrakow.Launcher"),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
            );
            Toast.makeText(this, "Ikona ukryta. Widżet nadal działa.", Toast.LENGTH_LONG).show();
        });

        setContentView(r);
    }
}
