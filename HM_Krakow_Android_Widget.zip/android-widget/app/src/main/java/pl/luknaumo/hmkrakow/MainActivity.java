package pl.luknaumo.hmkrakow;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** A small setup screen; the training application stays in the user's browser. */
public final class MainActivity extends Activity {
    private static final int BACKGROUND = Color.rgb(16, 16, 16);
    private static final int GOLD = Color.rgb(255, 206, 0);
    private Button refreshButton;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        scroll.setClipToPadding(false);
        scroll.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
            } else {
                view.setPadding(insets.getSystemWindowInsetLeft(),
                        insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(),
                        insets.getSystemWindowInsetBottom());
            }
            return insets;
        });

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(24), dp(32), dp(24), dp(24));
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView label = text(R.string.setup_label, 13, GOLD);
        label.setLetterSpacing(0.09f);
        label.setTypeface(null, Typeface.BOLD);
        content.addView(label);
        TextView title = text(R.string.app_name, 30, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        add(content, title, 12);
        add(content, text(R.string.goal_label, 16, Color.rgb(213, 213, 213)), 10);
        add(content, text(R.string.setup_description, 17, Color.rgb(230, 230, 230)), 28);

        Button addWidget = button(R.string.add_widget, GOLD, Color.BLACK);
        add(content, addWidget, 28);
        addWidget.setOnClickListener(view -> pinWidget());
        Button open = button(R.string.open_app, Color.rgb(39, 39, 39), Color.WHITE);
        add(content, open, 12);
        open.setOnClickListener(view -> startActivity(new Intent(this, OpenPlanActivity.class)));

        refreshButton = button(R.string.refresh_plan, Color.rgb(39, 39, 39), GOLD);
        add(content, refreshButton, 12);
        refreshButton.setOnClickListener(view -> {
            if (!hasWidgets()) {
                showManualInstructions();
                return;
            }
            HMWidgetProvider.updateAll(this);
            WidgetScheduler.ensure(this);
            WidgetScheduler.requestRefresh(this);
            Toast.makeText(this, R.string.refresh_requested, Toast.LENGTH_SHORT).show();
        });

        add(content, text(R.string.setup_manual_instructions, 15,
                Color.rgb(180, 180, 180)), 24);
        setContentView(scroll);
        scroll.requestApplyInsets();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean installed = hasWidgets();
        refreshButton.setEnabled(installed);
        refreshButton.setAlpha(installed ? 1f : 0.45f);
        if (installed) {
            HMWidgetProvider.updateAll(this);
            WidgetScheduler.ensure(this);
            WidgetScheduler.requestRefresh(this);
        }
    }

    private boolean hasWidgets() {
        return AppWidgetManager.getInstance(this).getAppWidgetIds(
                new ComponentName(this, HMWidgetProvider.class)).length > 0;
    }

    private void pinWidget() {
        AppWidgetManager manager = getSystemService(AppWidgetManager.class);
        ComponentName provider = new ComponentName(this, HMWidgetProvider.class);
        if (manager != null && manager.isRequestPinAppWidgetSupported()
                && manager.requestPinAppWidget(provider, null, null)) return;
        showManualInstructions();
    }

    private void showManualInstructions() {
        Toast.makeText(this, R.string.setup_manual_instructions, Toast.LENGTH_LONG).show();
    }

    private TextView text(int stringId, int sizeSp, int color) {
        TextView result = new TextView(this);
        result.setText(stringId);
        result.setTextColor(color);
        result.setTextSize(sizeSp);
        result.setLineSpacing(dp(3), 1f);
        return result;
    }

    private Button button(int stringId, int fill, int color) {
        Button result = new Button(this);
        result.setText(stringId);
        result.setTextSize(16);
        result.setTextColor(color);
        result.setAllCaps(false);
        result.setMinHeight(dp(52));
        result.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable background = new GradientDrawable();
        background.setColor(fill);
        background.setCornerRadius(dp(14));
        result.setBackground(background);
        return result;
    }

    private void add(LinearLayout parent, View child, int topMarginDp) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.topMargin = dp(topMarginDp);
        parent.addView(child, params);
    }
}
