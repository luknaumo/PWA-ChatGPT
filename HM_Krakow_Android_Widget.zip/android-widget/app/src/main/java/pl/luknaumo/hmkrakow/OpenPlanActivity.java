package pl.luknaumo.hmkrakow;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;

/** An explicit widget tap opens the installed PWA or the user's chosen browser. */
public final class OpenPlanActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(PlanData.PWA_URL))
                    .addCategory(Intent.CATEGORY_BROWSABLE));
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(this, R.string.open_app_unavailable, Toast.LENGTH_LONG).show();
        } finally {
            finish();
        }
    }
}
