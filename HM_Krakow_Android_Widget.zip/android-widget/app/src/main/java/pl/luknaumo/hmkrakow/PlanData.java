package pl.luknaumo.hmkrakow;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** The same dated, seven-day plan consumed by the PWA. Completion stays in the browser. */
public final class PlanData {
    public static final String PWA_URL = "https://luknaumo.github.io/PWA-ChatGPT/";
    public static final String PLAN_URL = PWA_URL + "plan.json";

    public static final class Day {
        public final LocalDate date;
        public final String title;
        public final String meta;
        public final String details;
        public final String tag;

        private Day(LocalDate date, String title, String meta, String details, String tag) {
            this.date = date;
            this.title = title;
            this.meta = meta;
            this.details = details;
            this.tag = tag;
        }
    }

    public static final class Plan {
        public final String appName;
        public final String goalName;
        public final String goalLocation;
        public final LocalDate goalDate;
        public final LocalDate weekStart;
        public final LocalDate weekEnd;
        public final String weekTitle;
        public final String weekNote;
        private final Map<LocalDate, Day> days;

        private Plan(String appName, String goalName, String goalLocation, LocalDate goalDate,
                     LocalDate weekStart, LocalDate weekEnd, String weekTitle, String weekNote,
                     Map<LocalDate, Day> days) {
            this.appName = appName;
            this.goalName = goalName;
            this.goalLocation = goalLocation;
            this.goalDate = goalDate;
            this.weekStart = weekStart;
            this.weekEnd = weekEnd;
            this.weekTitle = weekTitle;
            this.weekNote = weekNote;
            this.days = Collections.unmodifiableMap(new LinkedHashMap<>(days));
        }

        /** Dates outside this week deliberately return null instead of repeating a weekday. */
        public Day dayFor(LocalDate date) {
            return days.get(date);
        }
    }

    public static Plan parse(String json) {
        if (json == null) {
            throw new IllegalArgumentException("Brak planu");
        }
        try {
            JSONTokener tokens = new JSONTokener(json);
            Object document = tokens.nextValue();
            if (!(document instanceof JSONObject) || tokens.nextClean() != 0) {
                throw new IllegalArgumentException("Niepoprawny dokument planu");
            }
            JSONObject root = (JSONObject) document;
            String appName = text(root, "appName");
            JSONObject goal = root.getJSONObject("goal");
            String goalName = text(goal, "name");
            String goalLocation = text(goal, "location");
            LocalDate goalDate = date(goal, "date");
            JSONObject week = root.getJSONObject("week");
            LocalDate weekStart = date(week, "start");
            LocalDate weekEnd = date(week, "end");
            String weekTitle = text(week, "title");
            String weekNote = text(week, "note");
            JSONArray sourceDays = root.getJSONArray("days");
            if (sourceDays.length() != 7 || !weekStart.plusDays(6).equals(weekEnd)) {
                throw new IllegalArgumentException("Plan musi zawierać siedem kolejnych dni");
            }
            Map<LocalDate, Day> days = new LinkedHashMap<>();
            for (int index = 0; index < sourceDays.length(); index++) {
                JSONObject day = sourceDays.getJSONObject(index);
                LocalDate dayDate = date(day, "d");
                if (!weekStart.plusDays(index).equals(dayDate)) {
                    throw new IllegalArgumentException("Niepoprawna kolejność dat treningów");
                }
                // The website permits an optional default status; this helper does not sync it.
                if (day.has("done") && !(day.get("done") instanceof Boolean)) {
                    throw new IllegalArgumentException("Niepoprawny status treningu");
                }
                days.put(dayDate, new Day(dayDate, text(day, "title"), text(day, "meta"),
                        text(day, "details"), text(day, "tag")));
            }
            return new Plan(appName, goalName, goalLocation, goalDate, weekStart, weekEnd,
                    weekTitle, weekNote, days);
        } catch (JSONException | DateTimeParseException exception) {
            throw new IllegalArgumentException("Niepoprawny format planu", exception);
        }
    }

    private static String text(JSONObject object, String key) throws JSONException {
        Object value = object.get(key);
        if (!(value instanceof String) || isBlank((String) value)) {
            throw new IllegalArgumentException("Brak tekstu: " + key);
        }
        return (String) value;
    }

    private static boolean isBlank(String text) {
        for (int index = 0; index < text.length(); index++) {
            char character = text.charAt(index);
            if (!Character.isWhitespace(character) && !Character.isSpaceChar(character)
                    && character != '\uFEFF') {
                return false;
            }
        }
        return true;
    }

    private static LocalDate date(JSONObject object, String key) throws JSONException {
        String value = text(object, key);
        if (!value.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}")) {
            throw new IllegalArgumentException("Niepoprawna data: " + key);
        }
        return LocalDate.parse(value);
    }

    private PlanData() { }
}
