package pl.luknaumo.hmkrakow;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public final class PlanData {
    public static final String PWA_URL = "https://luknaumo.github.io/PWA-ChatGPT/";
    public static final LocalDate RACE_DATE = LocalDate.of(2026, 10, 11);

    public static final class Day {
        public final String title, details, label;
        public Day(String title, String details, String label) {
            this.title = title; this.details = details; this.label = label;
        }
    }

    public static Day forDate(LocalDate d) {
        switch (d.toString()) {
            case "2026-10-05": return new Day("Easy run ✓", "5,34 km · 6:01/km · HR 134", "REGENERACJA");
            case "2026-10-06": return new Day("Bardzo lekki bieg", "3–4 km · 6:10–6:35/km", "EASY");
            case "2026-10-07": return new Day("Tempo HM", "5–6 km · 3 × 1 km @ 5:15–5:20", "KLUCZOWY");
            case "2026-10-08": return new Day("Odpoczynek", "Spacery + 10–15 min mobilności", "REST");
            case "2026-10-09": return new Day("Rozruch", "3–4 km easy + 3 × 20 s przebieżki", "LEKKO");
            case "2026-10-10": return new Day("Kraków · odpoczynek", "Spacer · nawodnienie · węgle", "TAPER");
            case "2026-10-11": return new Day("PÓŁMARATON", "21,1 km · cel 1:52 · 5:18/km", "START");
            default:
                if (d.isAfter(RACE_DATE)) return new Day("Półmaraton za Tobą", "Dotknij, aby otworzyć plan", "META");
                return new Day("Taper do Krakowa", "Dotknij, aby otworzyć pełny plan", "PLAN");
        }
    }

    public static String countdown(LocalDate d) {
        long days = ChronoUnit.DAYS.between(d, RACE_DATE);
        if (days > 1) return String.valueOf(days);
        if (days == 1) return "1";
        if (days == 0) return "START";
        return "✓";
    }

    public static String countdownCaption(LocalDate d) {
        long days = ChronoUnit.DAYS.between(d, RACE_DATE);
        if (days > 1) return "DNI DO HM";
        if (days == 1) return "DZIEŃ DO HM";
        if (days == 0) return "HM KRAKÓW";
        return "HM KRAKÓW";
    }

    public static String nextLine(LocalDate d) {
        if (d.isBefore(RACE_DATE)) return "Jutro: " + forDate(d.plusDays(1)).title;
        return "Cel: 1:52:00";
    }

    private PlanData() {}
}
