package pl.luknaumo.hmkrakow;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public final class PlanData {
    public static final String PWA_URL = "https://luknaumo.github.io/PWA-ChatGPT/";
    public static final LocalDate RACE_DATE = LocalDate.of(2026, 10, 11);

    public static final class Day {
        public final String title;
        public final String details;
        public Day(String title, String details) {
            this.title = title;
            this.details = details;
        }
    }

    public static Day forDate(LocalDate d) {
        String key = d.toString();
        switch (key) {
            case "2026-10-05": return new Day("Easy run ✓", "5,34 km · 6:01/km · HR 134");
            case "2026-10-06": return new Day("Bardzo lekki bieg", "3–4 km · 6:10–6:35/km · HR 130–145");
            case "2026-10-07": return new Day("Tempo HM", "5–6 km · 3 × 1 km @ 5:15–5:20/km");
            case "2026-10-08": return new Day("Odpoczynek", "Spacery + 10–15 min mobilności");
            case "2026-10-09": return new Day("Rozruch", "3–4 km easy + 3 × 20 s przebieżki");
            case "2026-10-10": return new Day("Kraków · odpoczynek", "Lekki spacer · nawodnienie · węglowodany");
            case "2026-10-11": return new Day("PÓŁMARATON", "21,1 km · cel 1:52 · 5:18/km");
            default:
                if (d.isAfter(RACE_DATE)) {
                    return new Day("Półmaraton za Tobą", "Dotknij, aby otworzyć plan");
                }
                return new Day("Taper do Krakowa", "Dotknij, aby otworzyć pełny plan");
        }
    }

    public static String countdown(LocalDate d) {
        long days = ChronoUnit.DAYS.between(d, RACE_DATE);
        if (days > 1) return "HM KRAKÓW · " + days + " dni";
        if (days == 1) return "HM KRAKÓW · JUTRO";
        if (days == 0) return "HM KRAKÓW · DZISIAJ";
        return "HM KRAKÓW";
    }

    public static String nextLine(LocalDate d) {
        if (d.isBefore(RACE_DATE)) {
            Day next = forDate(d.plusDays(1));
            return "Jutro: " + next.title;
        }
        return "Cel: 1:52:00";
    }

    private PlanData() {}
}
