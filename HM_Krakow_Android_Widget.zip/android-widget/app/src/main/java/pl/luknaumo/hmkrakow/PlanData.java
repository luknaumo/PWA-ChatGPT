package pl.luknaumo.hmkrakow;
import java.util.Calendar;
public final class PlanData {
 public static final String PWA_URL="https://luknaumo.github.io/PWA-ChatGPT/";
 public static final class Day { public final String title,details; Day(String t,String d){title=t;details=d;} }
 private static String key(Calendar c){return String.format("%04d-%02d-%02d",c.get(Calendar.YEAR),c.get(Calendar.MONTH)+1,c.get(Calendar.DAY_OF_MONTH));}
 public static Day today(){ Calendar c=Calendar.getInstance(); switch(key(c)){
  case "2026-10-05": return new Day("Easy run ✓","5,34 km · 6:01/km · HR 134");
  case "2026-10-06": return new Day("Bardzo lekki bieg","3–4 km · 6:10–6:35/km");
  case "2026-10-07": return new Day("Tempo HM","5–6 km · 3 × 1 km @ 5:15–5:20");
  case "2026-10-08": return new Day("Odpoczynek","Spacery + 10–15 min mobilności");
  case "2026-10-09": return new Day("Rozruch","3–4 km easy + 3 × 20 s przebieżki");
  case "2026-10-10": return new Day("Kraków · odpoczynek","Spacer · nawodnienie · węgle");
  case "2026-10-11": return new Day("PÓŁMARATON","21,1 km · cel 1:52 · 5:18/km");
  default:return new Day("HM Kraków","Dotknij, aby otworzyć plan");}}
 public static Day tomorrow(){Calendar c=Calendar.getInstance();c.add(Calendar.DAY_OF_MONTH,1);switch(key(c)){
  case "2026-10-07": return new Day("Tempo HM",""); case "2026-10-08": return new Day("Odpoczynek",""); case "2026-10-09": return new Day("Rozruch",""); case "2026-10-10": return new Day("Kraków · odpoczynek",""); case "2026-10-11": return new Day("PÓŁMARATON",""); default:return new Day("Plan w PWA","");}}
 public static String countdown(){Calendar now=Calendar.getInstance();Calendar race=Calendar.getInstance();race.set(2026,Calendar.OCTOBER,11,0,0,0);race.set(Calendar.MILLISECOND,0);now.set(Calendar.HOUR_OF_DAY,0);now.set(Calendar.MINUTE,0);now.set(Calendar.SECOND,0);now.set(Calendar.MILLISECOND,0);long d=(race.getTimeInMillis()-now.getTimeInMillis())/86400000L; if(d>1)return "HM KRAKÓW · "+d+" dni";if(d==1)return "HM KRAKÓW · JUTRO";if(d==0)return "HM KRAKÓW · DZISIAJ";return "HM KRAKÓW";}
 private PlanData(){}
}
