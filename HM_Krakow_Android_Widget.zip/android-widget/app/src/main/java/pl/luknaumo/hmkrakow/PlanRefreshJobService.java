package pl.luknaumo.hmkrakow;

import android.app.job.JobParameters;
import android.app.job.JobService;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

/** Short network jobs, with one cancellable task for each periodic/manual job ID. */
public final class PlanRefreshJobService extends JobService {
    private final ExecutorService executor = Executors.newFixedThreadPool(2);
    private final Map<Integer, RunningJob> running = new HashMap<>();

    private static final class RunningJob {
        final JobParameters parameters;
        FutureTask<Void> task;

        RunningJob(JobParameters parameters) {
            this.parameters = parameters;
        }
    }

    @Override
    public boolean onStartJob(JobParameters parameters) {
        if (!WidgetScheduler.hasWidgets(this)) {
            return false;
        }
        RunningJob job = new RunningJob(parameters);
        job.task = new FutureTask<>(() -> {
            try {
                PlanRepository.refresh(getApplicationContext());
                synchronized (running) {
                    if (running.get(parameters.getJobId()) != job
                            || Thread.currentThread().isInterrupted()) {
                        return null;
                    }
                }
                HMWidgetProvider.updateAll(getApplicationContext());
            } finally {
                boolean completed;
                synchronized (running) {
                    completed = running.get(parameters.getJobId()) == job;
                    if (completed) {
                        running.remove(parameters.getJobId());
                    }
                }
                if (completed) {
                    // Failures use the saved plan. The next periodic or manual request retries.
                    jobFinished(parameters, false);
                }
            }
            return null;
        });
        synchronized (running) {
            RunningJob previous = running.put(parameters.getJobId(), job);
            if (previous != null) {
                previous.task.cancel(true);
            }
        }
        executor.execute(job.task);
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters parameters) {
        synchronized (running) {
            RunningJob job = running.get(parameters.getJobId());
            // A stop for an older run must not cancel a replacement with the same job ID.
            if (job != null && job.parameters == parameters) {
                running.remove(parameters.getJobId());
                job.task.cancel(true);
            }
        }
        return false;
    }

    @Override
    public void onDestroy() {
        synchronized (running) {
            for (RunningJob job : running.values()) {
                job.task.cancel(true);
            }
            running.clear();
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
