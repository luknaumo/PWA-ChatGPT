package pl.luknaumo.hmkrakow;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.locks.ReentrantLock;

/** Validates a complete response before replacing the last usable local plan. */
public final class PlanRepository {
    private static final String PREFERENCES = "road_to_berlin_plan";
    private static final String KEY_PLAN = "plan_json";
    private static final String KEY_FETCHED_AT = "last_fetched_at";
    private static final String KEY_FAILED = "last_request_failed";
    private static final int MAX_PLAN_BYTES = 512 * 1024;
    private static final int TIMEOUT_MILLIS = 8000;
    // Periodic and manual jobs can coexist. Their requests must not overwrite each other's result.
    private static final ReentrantLock REFRESH_LOCK = new ReentrantLock();

    public static final class Snapshot {
        public final PlanData.Plan plan;
        public final long lastFetchedAt;
        public final boolean lastRequestFailed;

        private Snapshot(PlanData.Plan plan, long lastFetchedAt, boolean lastRequestFailed) {
            this.plan = plan;
            this.lastFetchedAt = lastFetchedAt;
            this.lastRequestFailed = lastRequestFailed;
        }
    }

    /** Reads only local storage. The bundled plan also works before the first network request. */
    public static Snapshot load(Context context) {
        // Read one consistent preference snapshot while a background fetch may commit new values.
        Map<String, ?> saved = preferences(context).getAll();
        PlanData.Plan plan = null;
        long fetchedAt = 0;
        String savedJson = saved.get(KEY_PLAN) instanceof String ? (String) saved.get(KEY_PLAN) : null;
        if (savedJson != null) {
            try {
                plan = PlanData.parse(savedJson);
                fetchedAt = saved.get(KEY_FETCHED_AT) instanceof Long
                        ? (Long) saved.get(KEY_FETCHED_AT) : 0;
            } catch (IllegalArgumentException ignored) {
                // A damaged saved response must never stop the widget from showing the seed plan.
            }
        }
        if (plan == null) {
            try (InputStream input = context.getAssets().open("plan.json")) {
                plan = PlanData.parse(readLimited(input));
            } catch (IOException | IllegalArgumentException ignored) {
                // UI displays a clear missing-plan state when neither source is usable.
            }
        }
        return new Snapshot(plan, fetchedAt, Boolean.TRUE.equals(saved.get(KEY_FAILED)));
    }

    /** Must be called by a background worker. Cancellation preserves the previous result. */
    public static boolean refresh(Context context) {
        boolean locked = false;
        HttpURLConnection connection = null;
        try {
            REFRESH_LOCK.lockInterruptibly();
            locked = true;
            checkInterrupted();
            connection = (HttpURLConnection) new URL(PlanData.PLAN_URL).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(TIMEOUT_MILLIS);
            connection.setReadTimeout(TIMEOUT_MILLIS);
            connection.setUseCaches(false);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Cache-Control", "no-cache, no-store");
            connection.setRequestProperty("Pragma", "no-cache");
            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new IOException("Nie udało się pobrać planu");
            }
            if (connection.getContentLengthLong() > MAX_PLAN_BYTES) {
                throw new IOException("Plan przekracza dozwolony rozmiar");
            }
            String json;
            try (InputStream input = connection.getInputStream()) {
                json = readLimited(input);
            }
            PlanData.parse(json);
            checkInterrupted();
            // commit completes the small local write before the worker redraws RemoteViews.
            return preferences(context).edit()
                    .putString(KEY_PLAN, json)
                    .putLong(KEY_FETCHED_AT, System.currentTimeMillis())
                    .putBoolean(KEY_FAILED, false)
                    .commit();
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            return false;
        } catch (IOException | IllegalArgumentException exception) {
            if (!Thread.currentThread().isInterrupted()) {
                preferences(context).edit().putBoolean(KEY_FAILED, true).commit();
            }
            return false;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (locked) {
                REFRESH_LOCK.unlock();
            }
        }
    }

    private static SharedPreferences preferences(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);
    }

    private static String readLimited(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int read;
        while ((read = input.read(buffer)) != -1) {
            checkInterrupted();
            if (output.size() + read > MAX_PLAN_BYTES) {
                throw new IOException("Plan przekracza dozwolony rozmiar");
            }
            output.write(buffer, 0, read);
        }
        return new String(output.toByteArray(), StandardCharsets.UTF_8);
    }

    private static void checkInterrupted() throws InterruptedIOException {
        if (Thread.currentThread().isInterrupted()) {
            throw new InterruptedIOException("Pobieranie anulowane");
        }
    }

    private PlanRepository() { }
}
