package pl.luknaumo.hmkrakow;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import java.time.Clock;
import java.time.LocalDate;
import java.util.concurrent.TimeUnit;

/** Network refreshes and local day changes are separate, so the date also changes offline. */
public final class WidgetScheduler {
    public static final int PERIODIC_JOB_ID = 270401;
    public static final int REFRESH_JOB_ID = 270402;
    private static final int MIDNIGHT_REQUEST_CODE = 270403;

    public static void ensure(Context context) {
        if (!hasWidgets(context)) {
            cancel(context);
            return;
        }
        JobScheduler scheduler = context.getSystemService(JobScheduler.class);
        if (scheduler != null && scheduler.getPendingJob(PERIODIC_JOB_ID) == null) {
            scheduler.schedule(new JobInfo.Builder(PERIODIC_JOB_ID,
                    new ComponentName(context, PlanRefreshJobService.class))
                    .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                    .setPeriodic(TimeUnit.HOURS.toMillis(1))
                    .setPersisted(true)
                    .build());
        }
        scheduleMidnight(context);
    }

    public static void requestRefresh(Context context) {
        if (!hasWidgets(context)) {
            return;
        }
        JobScheduler scheduler = context.getSystemService(JobScheduler.class);
        if (scheduler != null) {
            // No network constraint: an offline manual request still finishes using cached data.
            scheduler.schedule(new JobInfo.Builder(REFRESH_JOB_ID,
                    new ComponentName(context, PlanRefreshJobService.class))
                    .setOverrideDeadline(1000)
                    .build());
        }
    }

    public static void scheduleMidnight(Context context) {
        if (!hasWidgets(context)) {
            return;
        }
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        if (alarms != null) {
            // This inexact alarm needs no exact-alarm permission and may run after midnight in Doze.
            alarms.set(AlarmManager.RTC, nextMidnightMillis(Clock.systemDefaultZone()),
                    midnightIntent(context, PendingIntent.FLAG_UPDATE_CURRENT));
        }
    }

    public static long nextMidnightMillis(Clock clock) {
        return LocalDate.now(clock).plusDays(1).atStartOfDay(clock.getZone())
                .toInstant().toEpochMilli();
    }

    public static void cancel(Context context) {
        JobScheduler scheduler = context.getSystemService(JobScheduler.class);
        if (scheduler != null) {
            scheduler.cancel(PERIODIC_JOB_ID);
            scheduler.cancel(REFRESH_JOB_ID);
        }
        AlarmManager alarms = context.getSystemService(AlarmManager.class);
        PendingIntent alarm = midnightIntent(context, PendingIntent.FLAG_NO_CREATE);
        if (alarms != null && alarm != null) {
            alarms.cancel(alarm);
        }
    }

    static boolean hasWidgets(Context context) {
        return AppWidgetManager.getInstance(context).getAppWidgetIds(
                new ComponentName(context, HMWidgetProvider.class)).length > 0;
    }

    private static PendingIntent midnightIntent(Context context, int flags) {
        Intent intent = new Intent(context, HMWidgetProvider.class)
                .setAction(HMWidgetProvider.ACTION_DAY_CHANGED);
        return PendingIntent.getBroadcast(context, MIDNIGHT_REQUEST_CODE, intent,
                flags | PendingIntent.FLAG_IMMUTABLE);
    }

    private WidgetScheduler() { }
}
