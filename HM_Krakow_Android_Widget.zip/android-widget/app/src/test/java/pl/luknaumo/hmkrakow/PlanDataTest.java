package pl.luknaumo.hmkrakow;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Clock;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;

public class PlanDataTest {
    private static String realPlan() throws Exception {
        Path path = Paths.get("src/main/assets/plan.json");
        if (!Files.exists(path)) {
            path = Paths.get("app/src/main/assets/plan.json");
        }
        return new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
    }

    private static JSONObject source() throws Exception {
        return new JSONObject(realPlan());
    }

    @Test
    public void readsActualBundledBerlinPlan() throws Exception {
        PlanData.Plan plan = PlanData.parse(realPlan());
        assertEquals("Road to Berlin", plan.appName);
        assertEquals("Berlin Half Marathon", plan.goalName);
        assertEquals("Berlin", plan.goalLocation);
        assertEquals(LocalDate.of(2027, 4, 4), plan.goalDate);
        assertEquals(LocalDate.of(2026, 10, 12), plan.weekStart);
        assertEquals(LocalDate.of(2026, 10, 18), plan.weekEnd);
        assertEquals("Odpoczynek po starcie", plan.dayFor(plan.weekStart).title);
        assertEquals("Lekko", plan.dayFor(plan.weekEnd).tag);
        assertFalse(plan.dayFor(plan.weekStart).meta.isEmpty());
        assertFalse(plan.dayFor(plan.weekStart).details.isEmpty());
    }

    @Test
    public void doesNotRepeatWeekdaysOutsideThePublishedWeek() throws Exception {
        PlanData.Plan plan = PlanData.parse(realPlan());
        assertNull(plan.dayFor(LocalDate.of(2026, 10, 5)));
        assertNull(plan.dayFor(LocalDate.of(2026, 10, 19)));
        assertNull(plan.dayFor(LocalDate.of(2027, 10, 12)));
    }

    @Test
    public void matchesTheLocalDateAtTheUtcBoundary() throws Exception {
        PlanData.Plan plan = PlanData.parse(realPlan());
        Instant instant = Instant.parse("2026-10-11T22:30:00Z");
        assertEquals("Odpoczynek po starcie", plan.dayFor(LocalDate.now(
                Clock.fixed(instant, ZoneId.of("Europe/Warsaw")))).title);
        assertNull(plan.dayFor(LocalDate.now(Clock.fixed(instant, ZoneId.of("UTC")))));
    }

    @Test
    public void rejectsMalformedOrMissingData() throws Exception {
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse("{"));
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(null));
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse("{}"));
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(realPlan() + " garbage"));
        JSONObject root = source();
        root.getJSONObject("goal").remove("location");
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(root.toString()));
    }

    @Test
    public void rejectsNonStringAndBlankText() throws Exception {
        JSONObject number = source().put("appName", 123);
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(number.toString()));
        JSONObject blank = source();
        blank.getJSONObject("week").put("note", "\u00a0\uFEFF\t");
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(blank.toString()));
    }

    @Test
    public void rejectsImpossibleAndNonIsoDates() throws Exception {
        JSONObject impossible = source();
        impossible.getJSONObject("goal").put("date", "2027-02-30");
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(impossible.toString()));
        JSONObject nonIso = source();
        nonIso.getJSONObject("goal").put("date", "2027-4-4");
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(nonIso.toString()));
    }

    @Test
    public void requiresExactlySevenConsecutiveOrderedDays() throws Exception {
        JSONObject missing = source();
        missing.getJSONArray("days").remove(6);
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(missing.toString()));
        JSONObject duplicate = source();
        duplicate.getJSONArray("days").getJSONObject(1).put("d", "2026-10-12");
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(duplicate.toString()));
        JSONObject reversed = source();
        JSONArray days = reversed.getJSONArray("days");
        Object first = days.get(0);
        days.put(0, days.get(1));
        days.put(1, first);
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(reversed.toString()));
        JSONObject badEnd = source();
        badEnd.getJSONObject("week").put("end", "2026-10-19");
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(badEnd.toString()));
    }

    @Test
    public void validatesButDoesNotExposeWebsiteCompletionDefaults() throws Exception {
        JSONObject valid = source();
        valid.getJSONArray("days").getJSONObject(0).put("done", true);
        assertEquals("Odpoczynek po starcie", PlanData.parse(valid.toString())
                .dayFor(LocalDate.of(2026, 10, 12)).title);
        JSONObject invalid = source();
        invalid.getJSONArray("days").getJSONObject(0).put("done", "true");
        assertThrows(IllegalArgumentException.class, () -> PlanData.parse(invalid.toString()));
    }
}
