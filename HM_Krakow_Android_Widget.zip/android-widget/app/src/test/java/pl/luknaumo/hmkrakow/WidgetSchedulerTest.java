package pl.luknaumo.hmkrakow;

import org.junit.Test;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;

import static org.junit.Assert.assertEquals;

public class WidgetSchedulerTest {
    @Test
    public void schedulesTheNextLocalMidnightRatherThanUtcMidnight() {
        Clock clock = Clock.fixed(Instant.parse("2026-10-11T22:30:00Z"),
                ZoneId.of("Europe/Warsaw"));
        assertEquals(Instant.parse("2026-10-12T22:00:00Z").toEpochMilli(),
                WidgetScheduler.nextMidnightMillis(clock));
    }

    @Test
    public void advancesToTomorrowWhenCalledExactlyAtMidnight() {
        Clock clock = Clock.fixed(Instant.parse("2026-10-11T22:00:00Z"),
                ZoneId.of("Europe/Warsaw"));
        assertEquals(Instant.parse("2026-10-12T22:00:00Z").toEpochMilli(),
                WidgetScheduler.nextMidnightMillis(clock));
    }

    @Test
    public void handlesTheTwentyThreeHourDayAtSpringDstChange() {
        assertDayLength(LocalDate.of(2027, 3, 28), ZoneId.of("Europe/Warsaw"), 23);
    }

    @Test
    public void handlesTheTwentyFiveHourDayAtAutumnDstChange() {
        assertDayLength(LocalDate.of(2026, 10, 25), ZoneId.of("Europe/Warsaw"), 25);
    }

    @Test
    public void handlesZonesWithoutDstAndCalendarYearChanges() {
        ZoneId zone = ZoneId.of("Asia/Kolkata");
        Clock clock = Clock.fixed(Instant.parse("2026-12-31T12:00:00Z"), zone);
        assertEquals(Instant.parse("2026-12-31T18:30:00Z").toEpochMilli(),
                WidgetScheduler.nextMidnightMillis(clock));
    }

    private static void assertDayLength(LocalDate date, ZoneId zone, long hours) {
        Instant beginning = date.atStartOfDay(zone).toInstant();
        Clock clock = Clock.fixed(beginning, zone);
        assertEquals(Duration.ofHours(hours).toMillis(),
                WidgetScheduler.nextMidnightMillis(clock) - beginning.toEpochMilli());
    }
}
