HM Kraków Widget v2

Zmiany:
- brak ikony pomocniczej apki w szufladzie aplikacji,
- mniejszy widget 3x2,
- nadal otwiera PWA po dotknięciu,
- można go ręcznie rozciągać/zmniejszać na ekranie głównym.

Instalacja aktualizacji:
1. Podmień plik HM_Krakow_Android_Widget.zip w repozytorium.
2. Workflow zbuduje nowy APK.
3. Pobierz artifact HM-Krakow-Widget-APK.
4. Jeśli instalacja aktualizacji się nie powiedzie, odinstaluj starą pomocniczą apkę HM Kraków i zainstaluj nową.
5. Dodawanie widgetu: przytrzymaj pusty obszar ekranu głównego -> Widgety -> HM Kraków Widget.
